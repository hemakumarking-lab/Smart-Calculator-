# SmartCalc Android project

A simple native Android calculator project.

## Features
- Standard arithmetic
- Business-style percentage: `100000 + 18% = 118000`; `100000 - 18% = 82000`
- Multiplication/division percentage
- Sign toggle, decimal, backspace, clear

## Build the APK
1. Install Android Studio (with Android SDK Platform 35).
2. Open this `SmartCalc-Android` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

This workspace does not contain the Android SDK/Gradle build environment, so the APK itself has not been compiled here.
