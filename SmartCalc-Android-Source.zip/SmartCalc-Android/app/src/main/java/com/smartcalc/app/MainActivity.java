package com.smartcalc.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private TextView display, expression;
    private String current = "0", operator = null;
    private Double first = null;
    private boolean fresh = false;
    private final ArrayList<String> history = new ArrayList<>();
    private final DecimalFormat fmt = new DecimalFormat("#,##0.########");

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(16, 24, 40));
        getWindow().setNavigationBarColor(Color.rgb(16, 24, 40));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 28, 20, 18);
        root.setBackgroundColor(Color.rgb(16, 24, 40));
        setContentView(root);

        TextView title = new TextView(this);
        title.setText("SmartCalc");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        expression = new TextView(this);
        expression.setTextColor(Color.LTGRAY);
        expression.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        expression.setTextSize(16);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, 48);
        ep.topMargin = 24;
        root.addView(expression, ep);

        display = new TextView(this);
        display.setText("0");
        display.setTextColor(Color.WHITE);
        display.setTextSize(40);
        display.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        display.setSingleLine(true);
        root.addView(display, new LinearLayout.LayoutParams(-1, 82));

        String[][] keys = {
            {"AC", "±", "%", "÷"},
            {"7", "8", "9", "×"},
            {"4", "5", "6", "−"},
            {"1", "2", "3", "+"},
            {"0", ".", "⌫", "="}
        };
        for (String[] row : keys) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 1);
            lp.topMargin = 7;
            root.addView(line, lp);
            for (String key : row) {
                Button btn = new Button(this);
                btn.setText(key);
                btn.setTextSize(20);
                btn.setAllCaps(false);
                btn.setTextColor(Color.WHITE);
                int bg = key.equals("=") ? Color.rgb(22, 163, 74) :
                    ("÷×−+".contains(key) && key.length() == 1) ? Color.rgb(37, 99, 235) :
                    ("AC±%⌫".contains(key) && key.length() == 1) ? Color.rgb(71, 85, 105) :
                    Color.rgb(35, 47, 66);
                btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(bg));
                LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, -1, 1);
                bp.setMargins(3, 0, 3, 0);
                line.addView(btn, bp);
                btn.setOnClickListener(v -> press(key));
            }
        }

        TextView note = new TextView(this);
        note.setText("History is kept during this session");
        note.setTextColor(Color.GRAY);
        note.setTextSize(12);
        note.setPadding(0, 12, 0, 0);
        root.addView(note);
    }

    private void press(String key) {
        try {
            if (key.matches("[0-9]") || key.equals(".")) {
                if (fresh) { current = key.equals(".") ? "0." : key; fresh = false; }
                else if (key.equals(".") && current.contains(".")) return;
                else current = current.equals("0") && !key.equals(".") ? key : current + key;
            } else if (key.equals("AC")) {
                current = "0"; first = null; operator = null; fresh = false; expression.setText("");
            } else if (key.equals("⌫")) {
                if (!fresh) current = current.length() > 1 ? current.substring(0, current.length()-1) : "0";
            } else if (key.equals("±")) {
                current = fmt.format(-Double.parseDouble(current)).replace(",", "");
            } else if (key.equals("%")) {
                current = fmt.format(Double.parseDouble(current) / 100.0).replace(",", "");
            } else if (key.equals("=")) {
                calculate();
            } else {
                first = Double.parseDouble(current);
                operator = key;
                expression.setText(fmt.format(first) + " " + operator);
                fresh = true;
            }
            display.setText(current);
        } catch (Exception e) { current = "Error"; display.setText(current); first = null; operator = null; fresh = true; }
    }

    private void calculate() {
        if (first == null || operator == null) return;
        double a = first, b = Double.parseDouble(current), result;
        // Business-calculator percentage: A + P% means A + (A * P / 100).
        if (operator.equals("+") || operator.equals("−")) {
            b = a * b / 100.0;
        } else if (operator.equals("×")) {
            b = a * b / 100.0;
        } else if (operator.equals("÷")) {
            b = b / 100.0;
        }
        switch (operator) {
            case "+": result = a + b; break;
            case "−": result = a - b; break;
            case "×": result = b; break;
            case "÷": result = (b == 0) ? Double.NaN : a / b; break;
            default: return;
        }
        String shown = Double.isFinite(result) ? fmt.format(result) : "Error";
        expression.setText(fmt.format(a) + " " + operator + " " + current + "%");
        current = shown.replace(",", "");
        display.setText(shown);
        first = null; operator = null; fresh = true;
    }
}
